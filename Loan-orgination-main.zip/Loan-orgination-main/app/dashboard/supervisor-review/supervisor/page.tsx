"use client";

import { useState, useEffect, ChangeEvent } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast, Toaster } from "sonner";
import { SaveReviewButton } from "@/components/Savereview";
import { Skeleton } from "@/components/ui/skeleton";
import {
  RefreshCw,
  FileText,
  User,
  MapPin,
  Briefcase,
  DollarSign,
  Calendar,
  Phone,
  Mail,
  IdCard,
  Building,
  CheckCircle2,
  Info,
  AlertCircle,
  BarChart3,
  ClipboardCheck,
  Star,
  Percent,
  FileEdit,
  Loader2,
} from "lucide-react";
import { useRouter } from "next/navigation";

// Define the interface for the LoanAnalysis model
interface LoanAnalysis {
  id: string;
  applicationReferenceNumber: string;
  financialProfileUrl?: string;
  pestelAnalysisUrl?: string;
  swotAnalysisUrl?: string;
  riskAssessmentUrl?: string;
  esgAssessmentUrl?: string;
  financialNeedUrl?: string;
  analystConclusion?: string;
  analystRecommendation?: string;
  rmRecommendation?: string;
  pestelanalysisScore?: number;
  swotanalysisScore?: number;
  riskassesmentScore?: number;
  esgassesmentScore?: number;
  financialneedScore?: number;
  overallScore?: number;
  reviewNotes?: string;
  decision?: string;
}

// Update the Customer interface to include the LoanAnalysis relation
interface Customer {
  companyName: string;
  annualRevenue: number;
  id: string;
  applicationReferenceNumber: string;
  customerNumber: string;
  tinNumber: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  mothersName?: string;
  gender: string;
  maritalStatus: string;
  dateOfBirth: string;
  nationalId: string;
  phone: string;
  email?: string;
  region: string;
  zone: string;
  city: string;
  subcity: string;
  woreda: string;
  monthlyIncome: number;
  status: string;
  accountType: string;
  nationalidUrl: string;
  agreementFormUrl: string;
  majorLineBusiness: string;
  majorLineBusinessUrl: string;
  otherLineBusiness?: string;
  otherLineBusinessUrl?: string;
  dateOfEstablishmentMLB: string;
  dateOfEstablishmentOLB?: string;
  purposeOfLoan: string;
  loanType: string;
  loanAmount: number;
  loanPeriod: number;
  modeOfRepayment: string;
  economicSector: string;
  customerSegmentation: string;
  creditInitiationCenter: string;
  applicationFormUrl: string;
  shareholdersDetailsUrl?: string;
  creditProfileUrl: string;
  transactionProfileUrl: string;
  collateralProfileUrl: string;
  financialProfileUrl: string;
  applicationStatus: string;
  createdAt: string;
  updatedAt: string;
  loanAnalysis: LoanAnalysis | null;
}

export default function PendingCustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loanAnalyses, setLoanAnalyses] = useState<
    Record<string, LoanAnalysis>
  >({});
  const [reviewData, setReviewData] = useState<
    Record<string, Partial<LoanAnalysis>>
  >({});
  const [refreshing, setRefreshing] = useState(false);

  const [isSupervisor, setIsSupervisor] = useState(false);

  const router = useRouter();

  useEffect(() => {
    // Check if the current user is a supervisor
    const checkRoleStatus = async () => {
      try {
        // Get the current user's role from your API
        const response = await fetch("/api/session");

        if (!response.ok) {
          throw new Error("Failed to fetch user session");
        }

        const data = await response.json();

        // Check if we have a valid session with user data
        if (!data || !data.user) {
          router.push("/");
          return;
        }

        // Check if user has supervisor role
        if (data.user.role === "SUPERVISOR") {
          setIsSupervisor(true);
        } else {
          // Redirect non-supervisor users to dashboard
          router.push("/dashboard");
        }
      } catch (error) {
        console.error("Error checking role status:", error);
        toast.error("Authentication check failed");
        router.push("/dashboard");
      } finally {
        setIsLoading(false);
      }
    };

    checkRoleStatus();
  }, [router]);

  useEffect(() => {
    fetchPendingCustomers();
  }, []);

  const fetchPendingCustomers = async () => {
    try {
      setRefreshing(true);
      const response = await fetch(
        `/api/supervisor?status=SUPERVISOR_REVIEWING`
      );
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to fetch pending customers");
      }
      const data = await response.json();
      setCustomers(data);

      // Fetch loan analyses for all customers
      await fetchAllLoanAnalyses(data);
      setError(null);
    } catch (err: any) {
      setError(
        err.message ||
          "We're having trouble connecting to the server. Please try again in a moment."
      );
      setCustomers([]);
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  };

  // Function to fetch loan analysis for a specific application reference number
  const fetchLoanAnalysis = async (
    applicationReferenceNumber: string
  ): Promise<LoanAnalysis | null> => {
    try {
      const response = await fetch(
        `/api/loan-analysis/${applicationReferenceNumber}`
      );
      if (!response.ok) {
        return null;
      }
      return await response.json();
    } catch {
      return null;
    }
  };

  // Function to fetch all loan analyses
  const fetchAllLoanAnalyses = async (customersData: Customer[]) => {
    try {
      const analyses: Record<string, LoanAnalysis> = {};
      const reviewDataTemp: Record<string, Partial<LoanAnalysis>> = {};

      // Fetch analyses for each customer
      for (const customer of customersData) {
        const analysis = await fetchLoanAnalysis(
          customer.applicationReferenceNumber
        );
        if (analysis) {
          analyses[customer.applicationReferenceNumber] = analysis;
          // Initialize review data with existing analysis values
          reviewDataTemp[customer.applicationReferenceNumber] = {
            pestelanalysisScore: analysis.pestelanalysisScore,
            swotanalysisScore: analysis.swotanalysisScore,
            riskassesmentScore: analysis.riskassesmentScore,
            esgassesmentScore: analysis.esgassesmentScore,
            financialneedScore: analysis.financialneedScore,
            overallScore: analysis.overallScore,
            reviewNotes: analysis.reviewNotes || "",
          };
        } else {
          // Initialize empty review data
          reviewDataTemp[customer.applicationReferenceNumber] = {
            pestelanalysisScore: undefined,
            swotanalysisScore: undefined,
            riskassesmentScore: undefined,
            esgassesmentScore: undefined,
            financialneedScore: undefined,
            overallScore: undefined,
            reviewNotes: "",
          };
        }
      }

      setLoanAnalyses(analyses);
      setReviewData(reviewDataTemp);
    } catch (err: any) {
      console.error("Error fetching loan analyses:", err);
    }
  };

  const validateSupervisorData = (refNumber: string) => {
    const errors: string[] = [];
    const review = reviewData[refNumber];

    // Check all required score fields
    if (review?.pestelanalysisScore === undefined || review.pestelanalysisScore === null) {
      errors.push("PESTEL Analysis score is required");
    } else if (review.pestelanalysisScore < 0 || review.pestelanalysisScore > 100) {
      errors.push("PESTEL Analysis score must be between 0 and 100");
    }
    
    if (review?.swotanalysisScore === undefined || review.swotanalysisScore === null) {
      errors.push("SWOT Analysis score is required");
    } else if (review.swotanalysisScore < 0 || review.swotanalysisScore > 100) {
      errors.push("SWOT Analysis score must be between 0 and 100");
    }
    
    if (review?.riskassesmentScore === undefined || review.riskassesmentScore === null) {
      errors.push("Risk Assessment score is required");
    } else if (review.riskassesmentScore < 0 || review.riskassesmentScore > 100) {
      errors.push("Risk Assessment score must be between 0 and 100");
    }
    
    if (review?.esgassesmentScore === undefined || review.esgassesmentScore === null) {
      errors.push("ESG Assessment score is required");
    } else if (review.esgassesmentScore < 0 || review.esgassesmentScore > 100) {
      errors.push("ESG Assessment score must be between 0 and 100");
    }
    
    if (review?.financialneedScore === undefined || review.financialneedScore === null) {
      errors.push("Financial Need score is required");
    } else if (review.financialneedScore < 0 || review.financialneedScore > 100) {
      errors.push("Financial Need score must be between 0 and 100");
    }
    
    if (!review?.reviewNotes || review?.reviewNotes.trim() === "") {
      errors.push("Review notes are required");
    }

    return errors;
  };

  const handleReviewChange = (
    refNumber: string,
    field: keyof LoanAnalysis,
    value: string | number
  ) => {
    setReviewData((prev) => {
      const newState = { ...prev[refNumber] };

      // Handle score fields separately
      if (
        field === "pestelanalysisScore" ||
        field === "swotanalysisScore" ||
        field === "riskassesmentScore" ||
        field === "esgassesmentScore" ||
        field === "financialneedScore"
      ) {
        let numericValue = typeof value === "string" ? parseInt(value) : value;

        if (isNaN(numericValue as number) || (numericValue as number) < 0) {
          newState[field] = undefined;
        } else if ((numericValue as number) > 100) {
          newState[field] = 100;
        } else {
          newState[field] = numericValue as number;
        }

        // Auto-calculate overall score
        const pestelanalysisScore = newState.pestelanalysisScore || 0;
        const swotanalysisScore = newState.swotanalysisScore || 0;
        const riskassesmentScore = newState.riskassesmentScore || 0;
        const esgassesmentScore = newState.esgassesmentScore || 0;
        const financialneedScore = newState.financialneedScore || 0;
        newState.overallScore =
          (pestelanalysisScore +
            swotanalysisScore +
            riskassesmentScore +
            esgassesmentScore +
            financialneedScore) /
          5;
      } else if (field === "reviewNotes") {
        newState[field] = value as string;
      }

      return {
        ...prev,
        [refNumber]: newState,
      };
    });
  };

  const handleRefreshAnalyses = async () => {
    setRefreshing(true);
    await fetchAllLoanAnalyses(customers);
    setRefreshing(false);
    toast.success("Loan analyses refreshed!");
  };

  const formatData = (value: string | number | undefined | null) => {
    if (value === undefined || value === null || value === "") {
      return <span className="text-gray-400">N/A</span>;
    }
    if (typeof value === "string" && value.startsWith("http")) {
      return (
        <a
          href={value}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800 hover:underline font-medium flex items-center gap-1"
        >
          <FileText size={14} />
          View Document
        </a>
      );
    }
    if (typeof value === "number" && value > 1000) {
      return new Intl.NumberFormat("en-ET", {
        style: "currency",
        currency: "ETB",
      }).format(value);
    }
    return value;
  };

  const getScoreColor = (score: number | undefined) => {
    if (score === undefined) return "text-gray-500";
    if (score >= 80) return "text-green-600 font-bold";
    if (score >= 60) return "text-yellow-600 font-bold";
    return "text-red-600 font-bold";
  };

  const getScoreBgColor = (score: number | undefined) => {
    if (score === undefined) return "bg-gray-100 text-gray-800";
    if (score >= 80) return "bg-green-100 text-green-800";
    if (score >= 60) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const CardSkeleton = () => (
    <Card className="max-w-6xl mx-auto">
      <CardHeader className="bg-gradient-to-r from-gray-100 to-gray-50 border-b border-gray-200 py-4">
        <Skeleton className="h-8 w-3/4 mb-2" />
        <Skeleton className="h-6 w-full" />
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="space-y-4">
            <Skeleton className="h-6 w-48 mb-2" />
            <div className="space-y-2">
              {[...Array(4)].map((_, j) => (
                <div
                  key={j}
                  className="flex justify-between items-center text-sm"
                >
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))}
            </div>
          </div>
        ))}
      </CardContent>
      <CardFooter className="bg-gray-50 border-t border-gray-200 flex justify-end py-4">
        <Skeleton className="h-10 w-32" />
      </CardFooter>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <p className="mt-4 text-gray-700">Checking permissions...</p>
        </div>
      </div>
    );
  }
  
  if (!isSupervisor) {
    return null;
  }

  return (
    <div className="container mx-auto p-4 md:p-6 bg-gray-50 min-h-screen">
      <title>In Progress | Loan Origination</title>
      <div className="flex flex-col items-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-2">
          Supervisor Review Dashboard
        </h1>
        <p className="text-gray-600 text-center max-w-2xl">
          Review and score loan applications. Provide your assessment and final
          decision.
        </p>

        <div className="flex gap-4 mt-6">
          <Button
            onClick={fetchPendingCustomers}
            variant="outline"
            className="gap-2 border-blue-500 text-blue-600 hover:bg-blue-50"
            disabled={refreshing}
          >
            <RefreshCw size={16} className={refreshing ? "animate-spin" : ""} />
            {refreshing ? "Refreshing..." : "Refresh Applications"}
          </Button>
        </div>
      </div>

      {error && (
        <div className="flex flex-col items-center p-8 bg-white rounded-2xl shadow-lg max-w-2xl mx-auto border-4 border-dashed border-gray-200 text-gray-700 mb-8">
          <div className="mb-6 p-4 bg-green-100 rounded-full">
          <CheckCircle2 className="text-green-600" size={48} />
          </div>
          <h2 className="text-3xl font-extrabold text-gray-900 mb-3">
           All Clear!
          </h2>
          <p className="text-lg text-gray-600 text-center mb-6 max-w-md">
             No applications pending supervisor review. Check back later for new
            submissions.
          </p>
          <Button
            onClick={fetchPendingCustomers}
            className="gap-2 bg-red-600 hover:bg-red-700 text-white"
            size="sm"
          >
            <RefreshCw size={14} />
            Try Again
          </Button>
        </div>
      )}

      {!isLoading && !error && customers.length === 0 && (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-2xl shadow-lg max-w-2xl mx-auto border-4 border-dashed border-gray-200">
          <div className="mb-6 p-4 bg-green-100 rounded-full">
            <CheckCircle2 className="text-green-600" size={48} />
          </div>
          <h2 className="text-3xl font-extrabold text-gray-900 mb-3">
            All Clear!
          </h2>
          <p className="text-lg text-gray-600 text-center mb-6 max-w-md">
            No applications pending supervisor review. Check back later for new
            submissions.
          </p>
          <Button
            onClick={fetchPendingCustomers}
            className="gap-2 bg-green-600 hover:bg-green-700 text-white"
          >
            <RefreshCw size={18} />
            Check for New Applications
          </Button>
        </div>
      )}

      {!isLoading && customers.length > 0 && (
        <div className="grid grid-cols-1 gap-6">
          {customers.map((customer) => {
            const analysis = loanAnalyses[customer.applicationReferenceNumber];
            const review =
              reviewData[customer.applicationReferenceNumber] || {};

            return (
              <Card
                key={customer.id}
                className="max-w-6xl mx-auto overflow-hidden border border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-blue-100 py-4 px-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle className="text-2xl text-gray-900 flex items-center gap-2 font-extrabold">
                        <User size={24} className="text-blue-600" />
                        {customer.customerNumber?.startsWith("COMP")
                          ? customer.companyName
                          : `${customer.firstName} ${customer.middleName} ${customer.lastName}`}
                      </CardTitle>

                      <CardDescription className="flex flex-col md:flex-row md:gap-4 mt-2 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <IdCard size={14} />
                          Ref:{" "}
                          <span className="font-medium text-gray-800">
                            {customer.applicationReferenceNumber}
                          </span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Building size={14} />
                          Customer No:{" "}
                          <span className="font-medium text-gray-800">
                            {customer.customerNumber}
                          </span>
                        </span>
                      </CardDescription>
                    </div>
                    <Badge
                      variant="secondary"
                      className="bg-yellow-100 text-yellow-800 border-yellow-200 self-start md:self-auto py-1 px-3 font-semibold text-sm"
                    >
                      {customer.applicationStatus}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Personal Information */}
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <User size={18} className="text-blue-600" />
                      Personal Information
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">TIN:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.tinNumber)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">National ID:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.nationalId)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600 flex items-center gap-1">
                          <Phone size={14} />
                          Phone:
                        </p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.phone)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600 flex items-center gap-1">
                          <Mail size={14} />
                          Email:
                        </p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.email)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Gender:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.gender)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Marital Status:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.maritalStatus)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Address & Income */}
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <MapPin size={18} className="text-blue-600" />
                      Address & Income
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Region:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.region)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Zone:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.zone)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">City:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.city)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Subcity:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.subcity)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Woreda:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.woreda)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600 flex items-center gap-1">
                          <DollarSign size={14} />
                          {customer.customerNumber?.startsWith("COMP")
                            ? "Annual Revenue:"
                            : "Monthly Income:"}
                        </p>
                        <p className="font-medium text-gray-800">
                          {formatData(
                            customer.customerNumber?.startsWith("COMP")
                              ? customer.annualRevenue || 0
                              : customer.monthlyIncome || 0
                          )}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Account Type:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.accountType)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Business Details */}
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <Briefcase size={18} className="text-blue-600" />
                      Business Details
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Major Business:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.majorLineBusiness)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600 flex items-center gap-1">
                          <Calendar size={14} />
                          Established:
                        </p>
                        <p className="font-medium text-gray-800">
                          {formatData(
                            new Date(
                              customer.dateOfEstablishmentMLB
                            ).toLocaleDateString()
                          )}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Economic Sector:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.economicSector)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Customer Segment:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.customerSegmentation)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Initiation Center:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.creditInitiationCenter)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Loan Details */}
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <DollarSign size={18} className="text-blue-600" />
                      Loan Details
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Loan Type:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.loanType)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Loan Amount:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.loanAmount)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Loan Period:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.loanPeriod)} months
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Repayment Mode:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.modeOfRepayment)}
                        </p>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <p className="text-gray-600">Purpose:</p>
                        <p className="font-medium text-gray-800">
                          {formatData(customer.purposeOfLoan)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Supporting Documents */}
                  <div className="space-y-4 md:col-span-2">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <FileText size={18} className="text-blue-600" />
                      Supporting Documents
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">National ID:</span>
                        {formatData(customer.nationalidUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">Agreement Form:</span>
                        {formatData(customer.agreementFormUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Major Business Doc:
                        </span>
                        {formatData(customer.majorLineBusinessUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">Application Form:</span>
                        {formatData(customer.applicationFormUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Shareholders Details:
                        </span>
                        {formatData(customer.shareholdersDetailsUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">Credit Profile:</span>
                        {formatData(customer.creditProfileUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Transaction Profile:
                        </span>
                        {formatData(customer.transactionProfileUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Collateral Profile:
                        </span>
                        {formatData(customer.collateralProfileUrl)}
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Financial Profile:
                        </span>
                        {formatData(customer.financialProfileUrl)}
                      </div>
                    </div>
                  </div>

                  {/* Loan Analysis Section */}
                  {analysis && (
                    <div className="space-y-4 md:col-span-2">
                      <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                        <BarChart3 size={18} className="text-blue-600" />
                        Loan Analysis
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">
                            PESTEL Analysis:
                          </span>
                          {formatData(analysis.pestelAnalysisUrl)}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">SWOT Analysis:</span>
                          {formatData(analysis.swotAnalysisUrl)}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">
                            Risk Assessment:
                          </span>
                          {formatData(analysis.riskAssessmentUrl)}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">ESG Assessment:</span>
                          {formatData(analysis.esgAssessmentUrl)}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600">Financial Need:</span>
                          {formatData(analysis.financialNeedUrl)}
                        </div>
                        <div className="col-span-2">
                          <div className="flex flex-col text-sm">
                            <span className="text-gray-600 mb-1">
                              Analyst Conclusion:
                            </span>
                            <span className="font-medium text-gray-800">
                              {formatData(analysis.analystConclusion)}
                            </span>
                          </div>
                        </div>
                        <div className="col-span-2">
                          <div className="flex flex-col text-sm">
                            <span className="text-gray-600 mb-1">
                              Analyst Recommendation:
                            </span>
                            <span className="font-medium text-gray-800">
                              {formatData(analysis.analystRecommendation)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Review Section */}
                  <div className="space-y-4 md:col-span-2">
                    <h3 className="font-bold text-lg text-gray-800 border-b border-blue-200 pb-2 flex items-center gap-2">
                      <ClipboardCheck size={18} className="text-blue-600" />
                      Review & Scoring
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700  items-center gap-1">
                          <Percent size={14} />
                          PESTEL Score
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="0-100"
                          value={review.pestelanalysisScore ?? ""}
                          onChange={(e) =>
                            handleReviewChange(
                              customer.applicationReferenceNumber,
                              "pestelanalysisScore",
                              parseInt(e.target.value)
                            )
                          }
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700 items-center gap-1">
                          <Percent size={14} />
                          SWOT Score
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="0-100"
                          value={review.swotanalysisScore ?? ""}
                          onChange={(e) =>
                            handleReviewChange(
                              customer.applicationReferenceNumber,
                              "swotanalysisScore",
                              parseInt(e.target.value)
                            )
                          }
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700  items-center gap-1">
                          <Percent size={14} />
                          Risk Score
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="0-100"
                          value={review.riskassesmentScore ?? ""}
                          onChange={(e) =>
                            handleReviewChange(
                              customer.applicationReferenceNumber,
                              "riskassesmentScore",
                              parseInt(e.target.value)
                            )
                          }
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700 items-center gap-1">
                          <Percent size={14} />
                          ESG Score
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="0-100"
                          value={review.esgassesmentScore ?? ""}
                          onChange={(e) =>
                            handleReviewChange(
                              customer.applicationReferenceNumber,
                              "esgassesmentScore",
                              parseInt(e.target.value)
                            )
                          }
                                                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                                            <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700  items-center gap-1">
                          <Percent size={14} />
                          Financial Need
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="0-100"
                          value={review.financialneedScore ?? ""}
                          onChange={(e) =>
                            handleReviewChange(
                              customer.applicationReferenceNumber,
                              "financialneedScore",
                              parseInt(e.target.value)
                            )
                          }
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div className="space-y-2 md:col-span-2 lg:col-span-5">
                        <label className="block text-sm font-medium text-gray-700  items-center gap-1">
                          <Star size={14} />
                          Overall Score
                        </label>
                        <div
                          className={`w-full p-2 border border-gray-300 rounded-md ${getScoreBgColor(
                            review.overallScore
                          )} text-center font-bold`}
                        >
                          {typeof review.overallScore === "number"
                            ? `${review.overallScore.toFixed(1)} / 100`
                            : "N/A"}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-700  items-center gap-1">
                        <FileEdit size={14} />
                        Review Notes
                      </label>
                      <textarea
                        placeholder="Enter your review notes here..."
                        value={review.reviewNotes || ""}
                        onChange={(e) =>
                          handleReviewChange(
                            customer.applicationReferenceNumber,
                            "reviewNotes",
                            e.target.value
                          )
                        }
                        rows={3}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div className="flex justify-end">
                      <SaveReviewButton
                        customerId={customer.id}
                        refNumber={customer.applicationReferenceNumber}
                        reviewData={reviewData}
                        validateData={validateSupervisorData}
                        onSuccess={() => {
                          console.log("Analysis saved successfully");
                          toast.success("Review saved successfully!");
                          fetchPendingCustomers();
                        }}
                        buttonText="Save Review"
                        newStatus="SUPERVISED"
                      />
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="bg-gray-50 border-t border-gray-200 flex justify-between items-center py-4 px-6">
                  <Button
                    onClick={() =>
                      fetchLoanAnalysis(
                        customer.applicationReferenceNumber
                      ).then(() => {
                        toast.success("Analysis refreshed!");
                      })
                    }
                    variant="outline"
                    className="gap-2"
                  >
                    <RefreshCw size={16} />
                    Refresh Analysis
                  </Button>
                  {analysis ? (
                    <Badge
                      variant="default"
                      className="bg-green-100 text-green-800 border-green-200"
                    >
                      Analysis Available
                    </Badge>
                  ) : (
                    <Badge
                      variant="secondary"
                      className="bg-gray-100 text-gray-800 border-gray-200"
                    >
                      No Analysis
                    </Badge>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
      <Toaster />
    </div>
  );
}